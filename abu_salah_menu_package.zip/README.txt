
# Abu Salah Menu
This is a simple static HTML menu for "Abu Salah El Kababgy".
- You can edit the `index.html` file directly to add new dishes, prices, or images.
- Replace the placeholder images by updating the <img src="..."> in each item.
- Host on GitHub Pages, Netlify, or any static web host for free.
